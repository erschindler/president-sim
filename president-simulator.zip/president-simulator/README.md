# The Presidency — Executive Simulation

A standalone, browser-based presidential simulator prototype built with React, TypeScript, and Vite. It uses a deterministic simulation engine and local browser persistence; it does not require Supabase, an AI API, or paid services.

## Features in this playable foundation

- Presidential dashboard and weekly turn advancement
- National indicators: approval, economic confidence, inflation pressure, unemployment pressure, fiscal pressure, national unity, stability, public trust, institutional health, corruption risk, defense readiness, and global standing
- Event-driven decisions with trade-offs, resource costs, and risk
- Domestic policy portfolio across ten policy areas
- Legislative bill pipeline with committee, floor, passage, and failure outcomes
- Executive actions with political-capital and institutional trade-offs
- Cabinet profiles with loyalty, competence, trust, ambition, stress, private priorities, and workload support
- Foreign relations with five fictional counterpart states and diplomacy actions
- National security and resilience dashboard
- Press log and public opinion signals
- Campaign resources, messaging, ground organization, and a simplified election clock
- Decision history and presidential legacy outcome
- Difficulty setting and automatic local save
- Responsive dark executive-office UI

## Run locally

Requires Node.js 20+ (or a compatible current Node release) and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Build and type-check

```bash
npm run typecheck
npm run build
```

## State and save behavior

Game state is stored in `localStorage` under `president-simulator-save-v1`. Starting a new presidency replaces the current local save. This initial implementation is a single-player local prototype; it does not synchronize state between devices.

## Simulation caveats

This is a playable systems foundation, not yet a complete political/economic model. Metrics use simplified deterministic formulas and seeded variation. Legislative thresholds, public opinion, diplomatic behavior, and election outcomes are abstractions. The foreign governments and officials are fictional. The code is structured so the simulation can later be expanded with richer agency systems, state-level politics, budgets, courts, intelligence analysis, military operations, disasters, long-term policy implementation, and an optional local cognition layer.

## Suggested next systems

1. Full budget and appropriations model with annual fiscal projections.
2. Agency implementation pipeline with capacity, compliance, delays, and policy feedback.
3. Detailed congressional membership, committee chairs, faction interests, and vote-by-vote bill negotiation.
4. Federal court system, judicial appointments, injunctions, and constitutional review.
5. State governors, federalism, and region-specific indicators.
6. Crisis command center with multi-stage emergencies and intelligence uncertainty.
7. More detailed diplomacy: treaties, alliances, sanctions, trade dependencies, arms control, and negotiation rounds.
8. Long-term campaign/election simulation with electoral map, turnout, fundraising, and opposition behavior.
9. Scenario editor and save slots/export-import.
10. Optional local LLM for richer adviser dialogue and event interpretation, while retaining deterministic fallback.

import { describe, expect, it } from 'vitest';
import { advanceWeek, createGame, diplomacyAction, proposeBill, resolveEvent, takeExecutiveAction } from './game';

describe('presidential simulation engine', () => {
  it('creates a playable presidency with an opening decision', () => {
    const state = createGame({ seed: 12345 });
    expect(state.week).toBe(1);
    expect(state.events.some(event => !event.resolved)).toBe(true);
    expect(state.cabinet.length).toBeGreaterThanOrEqual(6);
    expect(state.foreign.length).toBeGreaterThanOrEqual(4);
  });

  it('resolves an event once and records the decision', () => {
    const state = createGame({ seed: 12345 });
    const event = state.events.find(item => !item.resolved)!;
    const before = state.history.length;
    resolveEvent(state, event.id, event.choices[0].id);
    expect(event.resolved).toBe(true);
    expect(state.history.length).toBe(before + 1);
    const after = state.history.length;
    resolveEvent(state, event.id, event.choices[0].id);
    expect(state.history.length).toBe(after);
  });

  it('does not charge for an unaffordable event choice', () => {
    const state = createGame({ seed: 12345 });
    state.budget = 0;
    const event = state.events[0];
    const expensive = { ...event.choices[0], cost: 10 };
    event.choices[0] = expensive;
    resolveEvent(state, event.id, expensive.id);
    expect(state.budget).toBe(0);
    expect(event.resolved).toBe(false);
  });

  it('introduces legislation and progresses the world by a week', () => {
    const state = createGame({ seed: 77 });
    proposeBill(state, 'infrastructure');
    expect(state.congress.bills).toHaveLength(1);
    const priorWeek = state.week;
    const next = advanceWeek(state);
    expect(next.week).toBe(priorWeek + 1);
    expect(next.history.length).toBeGreaterThan(state.history.length);
    expect(['draft', 'committee', 'floor', 'passed', 'failed']).toContain(next.congress.bills[0].stage);
  });

  it('applies diplomatic actions to the selected counterpart', () => {
    const state = createGame({ seed: 99 });
    const foreign = state.foreign[0];
    const before = foreign.relation;
    diplomacyAction(state, foreign.id, 'summit');
    expect(foreign.relation).toBeGreaterThan(before);
    expect(state.history[0].title).toContain('Diplomatic action');
  });

  it('spends political capital on executive action and records it', () => {
    const state = createGame({ seed: 101 });
    const before = state.politicalCapital;
    takeExecutiveAction(state, 'order');
    expect(state.executiveOrders).toBe(1);
    expect(state.politicalCapital).toBeLessThan(before);
  });
});

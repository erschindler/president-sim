import type { Bill, Choice, ForeignState, Issue, Person, PolicyArea, WorldEvent } from './types';
import { id } from './rng';

export const baseIssues:Issue[] = [
 {id:'economy',name:'Cost of Living',support:68,urgency:88,status:'Public concern',description:'Households are feeling pressure from rent, groceries, insurance, and borrowing costs.',cost:18,partisan:38},
 {id:'health',name:'Healthcare Access',support:64,urgency:79,status:'Committee review',description:'Hospitals and insurers are pressing for certainty while families want lower out-of-pocket costs.',cost:22,partisan:27},
 {id:'climate',name:'Energy & Climate',support:51,urgency:61,status:'Contested',description:'Energy reliability, household bills, and long-term climate risk are colliding.',cost:20,partisan:76},
 {id:'immigration',name:'Border & Immigration',support:58,urgency:82,status:'Active negotiations',description:'Border capacity, asylum processing, employers, and local services are under pressure.',cost:16,partisan:81},
 {id:'education',name:'Education',support:57,urgency:55,status:'Policy development',description:'Schools face staffing gaps, uneven outcomes, and disputes over federal priorities.',cost:12,partisan:45},
 {id:'infrastructure',name:'Infrastructure',support:72,urgency:63,status:'Bipartisan opening',description:'Ports, bridges, water systems, power grids, and rural connections need investment.',cost:25,partisan:24},
 {id:'justice',name:'Public Safety & Justice',support:55,urgency:66,status:'Under review',description:'Communities want safety, fair enforcement, and confidence in institutions.',cost:14,partisan:57},
 {id:'defense',name:'National Defense',support:62,urgency:73,status:'Readiness review',description:'Defense planners are balancing deterrence, personnel strain, and procurement delays.',cost:28,partisan:42},
 {id:'housing',name:'Housing Affordability',support:70,urgency:77,status:'Drafting options',description:'Supply constraints, local rules, construction costs, and rents are driving frustration.',cost:19,partisan:33},
 {id:'technology',name:'AI & Technology',support:48,urgency:50,status:'Early policy work',description:'Rapid automation creates productivity opportunities alongside privacy, labor, and safety concerns.',cost:11,partisan:49},
];

export const baseCabinet:Person[] = [
 {id:'chief',name:'Mara Ellison',role:'Chief of Staff',faction:'Pragmatic',loyalty:78,competence:91,ambition:62,trust:84,publicProfile:'Relentless organizer; keeps the administration focused.',privateAgenda:'Wants a disciplined first year and fears the White House will overpromise.',stress:34},
 {id:'treasury',name:'Daniel Cho',role:'Treasury Secretary',faction:'Fiscal Hawk',loyalty:69,competence:94,ambition:49,trust:80,publicProfile:'Technocratic, market-sensitive, careful with forecasts.',privateAgenda:'Will resist unfunded promises and prefers gradual reforms.',stress:41},
 {id:'state',name:'Ambassador Leila Haddad',role:'Secretary of State',faction:'Internationalist',loyalty:82,competence:89,ambition:55,trust:87,publicProfile:'Experienced diplomat with a wide network of allies.',privateAgenda:'Wants alliances treated as long-term assets, not bargaining chips.',stress:38},
 {id:'defense',name:'General Thomas Rusk (Ret.)',role:'Secretary of Defense',faction:'Security First',loyalty:73,competence:90,ambition:38,trust:76,publicProfile:'Direct, respected by uniformed leadership.',privateAgenda:'Prioritizes readiness and clear command authority.',stress:47},
 {id:'comms',name:'Imani Brooks',role:'Communications Director',faction:'Campaign Loyalist',loyalty:93,competence:76,ambition:83,trust:71,publicProfile:'Fast-moving strategist who understands media cycles.',privateAgenda:'Wants visible wins and fears a narrative vacuum.',stress:58},
 {id:'policy',name:'Dr. Sofia Ramirez',role:'Domestic Policy Adviser',faction:'Reformist',loyalty:86,competence:88,ambition:51,trust:82,publicProfile:'Policy-focused coalition builder.',privateAgenda:'Wants durable legislation rather than symbolic announcements.',stress:43},
 {id:'counsel',name:'Elliot Mercer',role:'White House Counsel',faction:'Institutionalist',loyalty:77,competence:93,ambition:31,trust:88,publicProfile:'Cautious legal adviser who documents decisions.',privateAgenda:'Will flag legal risk even when it frustrates political timing.',stress:29},
 {id:'political',name:'Marcus Bell',role:'Legislative Affairs Director',faction:'Deal Maker',loyalty:80,competence:84,ambition:72,trust:74,publicProfile:'Knows committee chairs and counts votes obsessively.',privateAgenda:'Wants to be the person who can get difficult bills through Congress.',stress:51},
];

export const baseForeign:ForeignState[] = [
 {id:'northland',name:'Republic of Northland',leader:'President Anika Volkov',relation:48,tension:56,trade:64,military:82,reliability:52,issue:'Cyber activity and contested maritime boundaries'},
 {id:'pacifica',name:'Pacific Federation',leader:'Premier Kenji Watanabe',relation:72,tension:31,trade:87,military:78,reliability:82,issue:'Technology standards and regional security'},
 {id:'sundara',name:'Union of Sundara',leader:'Prime Minister Amara Okafor',relation:61,tension:35,trade:51,military:43,reliability:70,issue:'Critical minerals, infrastructure, and climate finance'},
 {id:'levant',name:'Levantine Republic',leader:'President Samir Nassar',relation:38,tension:72,trade:29,military:61,reliability:44,issue:'Ceasefire talks and humanitarian access'},
 {id:'europa',name:'European Compact',leader:'Council President Elise Moreau',relation:77,tension:24,trade:80,military:69,reliability:85,issue:'Industrial policy and alliance burden-sharing'},
];

export const openingEvent:WorldEvent = {
 id:'opening-brief',week:1,kind:'crisis',title:'The First Morning Briefing',severity:2,
 body:'Your administration inherits a tight legislative calendar, an anxious public, and several issues that cannot be solved by press conference. Your advisers disagree about what must happen first. The first week will set expectations for the entire term.',
 tags:['briefing','agenda'],resolved:false,
 choices:[
  {id:'listen',label:'Listen before announcing',description:'Spend the first week in agency briefings and private consultations.',effects:{publicTrust:2,stability:2},cost:1,risk:0},
  {id:'agenda',label:'Set an ambitious public agenda',description:'Deliver a detailed address with measurable first-100-day goals.',effects:{approval:2,publicTrust:1,unity:-1},cost:2,risk:1},
  {id:'markets',label:'Lead with economic reassurance',description:'Prioritize cost-of-living relief and fiscal predictability.',effects:{economy:1,approval:1,globalStanding:1},cost:1,risk:0},
 ]
};

const eventTemplates:Omit<WorldEvent,'id'|'week'|'resolved'>[] = [
 {kind:'economy',title:'Unexpected Inflation Report',body:'A new report shows price pressures cooling more slowly than forecasters expected. Households are skeptical of optimistic messaging, and financial markets are revising their rate outlook.',severity:3,tags:['economy','prices'],choices:[
  {id:'targeted',label:'Announce targeted cost relief',description:'Help exposed households while keeping the package limited.',effects:{approval:2,inflation:-1,deficit:3,publicTrust:1},cost:3,risk:1},
  {id:'caution',label:'Avoid a rushed response',description:'Ask Treasury for a revised forecast and explain the trade-offs.',effects:{publicTrust:2,approval:-1,stability:1},cost:1,risk:0},
  {id:'pressure',label:'Publicly pressure the central bank',description:'Demand faster relief, risking concern about institutional independence.',effects:{approval:1,inflation:1,publicTrust:-3,stability:-2},cost:0,risk:3,hiddenRisk:2},
 ]},
 {kind:'legislation',title:'A Narrow Bipartisan Opening',body:'A group of legislators from both parties signals interest in an infrastructure package. The opening is real but fragile: a few controversial provisions could collapse the coalition.',severity:2,tags:['congress','infrastructure'],choices:[
  {id:'narrow',label:'Negotiate a narrower bill',description:'Trade some ambition for a credible path to passage.',effects:{unity:2,stability:2,approval:1,deficit:2},cost:2,risk:0},
  {id:'bold',label:'Keep the full package intact',description:'Protect the original plan and dare opponents to reject it.',effects:{approval:2,unity:-3,stability:-1},cost:1,risk:2},
  {id:'delay',label:'Wait for a better moment',description:'Preserve leverage but risk losing the coalition.',effects:{unity:-1,publicTrust:-1},cost:0,risk:1},
 ]},
 {kind:'diplomacy',title:'A Quiet Diplomatic Channel',body:'A foreign government offers a private channel to reduce a growing regional dispute. The offer could create room for de-escalation, but allies want to know they will not be bypassed.',severity:3,tags:['foreign','security'],choices:[
  {id:'allies',label:'Coordinate with allies first',description:'Slower, but reinforces trust and reduces surprise.',effects:{globalStanding:2,stability:1},cost:2,risk:0},
  {id:'direct',label:'Open a direct presidential channel',description:'Move quickly and preserve flexibility, with alliance-management risk.',effects:{globalStanding:1,stability:2},cost:1,risk:2,hiddenRisk:1},
  {id:'public',label:'Make a public demand',description:'Signal resolve, but make private compromise harder.',effects:{globalStanding:-1,readiness:1,stability:-2},cost:0,risk:2},
 ]},
 {kind:'media',title:'A Story About Internal Dissent',body:'Several outlets report that senior advisers disagree over the administration’s priorities. The disagreement is normal, but the story may become a test of whether the White House is coordinated.',severity:2,tags:['media','staff'],choices:[
  {id:'transparent',label:'Acknowledge debate, explain the process',description:'Show that disagreement is being resolved through a clear process.',effects:{publicTrust:2,stability:1,approval:1},cost:1,risk:0},
  {id:'attack',label:'Attack the reporting',description:'Energize loyalists but risk making the story bigger.',effects:{approval:1,publicTrust:-2,unity:-1},cost:0,risk:2},
  {id:'ignore',label:'Ignore the story',description:'Avoid amplifying it, but leave the narrative unanswered.',effects:{publicTrust:-1},cost:0,risk:1},
 ]},
 {kind:'personnel',title:'A Cabinet Warning',body:'A senior official privately warns that one of the administration’s signature promises is operationally harder than campaign staff understood. The warning is credible, but acting on it could disappoint supporters.',severity:3,tags:['cabinet','delivery'],choices:[
  {id:'replan',label:'Revise the implementation plan',description:'Protect delivery credibility at the cost of a slower timetable.',effects:{publicTrust:2,approval:-1,institutionalHealth:2},cost:2,risk:0},
  {id:'push',label:'Demand the original deadline',description:'Maintain urgency but raise the risk of mistakes and staff burnout.',effects:{approval:1,stability:-2,institutionalHealth:-2},cost:1,risk:2},
  {id:'review',label:'Commission a rapid independent review',description:'Create a credible evidence base, while delaying the final decision.',effects:{publicTrust:1,institutionalHealth:1},cost:2,risk:0},
 ]},
 {kind:'opportunity',title:'A Technology Investment Offer',body:'A consortium proposes a major domestic investment in advanced manufacturing. The opportunity could create jobs, but it includes tax incentives, infrastructure demands, and questions about where the benefits will land.',severity:2,tags:['economy','technology'],choices:[
  {id:'conditional',label:'Negotiate enforceable public-benefit terms',description:'Tie incentives to jobs, training, and delivery milestones.',effects:{economy:2,education:1,deficit:2,publicTrust:1},cost:2,risk:1},
  {id:'fast',label:'Offer a fast-track package',description:'Maximize speed and headline value while accepting more fiscal risk.',effects:{economy:2,approval:2,deficit:4,corruption:1},cost:2,risk:2},
  {id:'decline',label:'Decline the offer as structured',description:'Avoid a weak deal, but the consortium may invest elsewhere.',effects:{publicTrust:1,economy:-1},cost:0,risk:1},
 ]},
 {kind:'crisis',title:'Severe Weather Disrupts a Region',body:'A severe weather system has damaged transport links and power infrastructure. Governors are asking for rapid federal coordination. Response quality will affect public confidence more than rhetoric.',severity:4,tags:['disaster','infrastructure'],choices:[
  {id:'surge',label:'Deploy a coordinated federal response',description:'Mobilize agencies and emergency resources quickly.',effects:{stability:3,publicTrust:2,deficit:3,climate:1},cost:4,risk:1},
  {id:'state',label:'Support state-led response',description:'Provide targeted support while leaving operational command local.',effects:{publicTrust:1,stability:1,deficit:1},cost:2,risk:1},
  {id:'message',label:'Focus on public messaging first',description:'Communicate reassurance while resources are still being organized.',effects:{approval:-2,publicTrust:-3,stability:-2},cost:0,risk:3,hiddenRisk:1},
 ]},
 {kind:'campaign',title:'Your Coalition Wants a Clear Win',body:'Supporters are asking for a visible achievement they can point to. Advisers warn that a symbolic victory may crowd out less visible work that matters more over time.',severity:2,tags:['politics','approval'],choices:[
  {id:'deliver',label:'Deliver a measurable policy milestone',description:'Choose a modest goal that agencies can actually complete.',effects:{approval:2,publicTrust:2,stability:1},cost:2,risk:0},
  {id:'rally',label:'Hold a high-energy national rally',description:'Energize supporters and dominate the news cycle briefly.',effects:{approval:2,unity:-1,publicTrust:-1},cost:2,risk:1},
  {id:'quiet',label:'Stay focused on implementation',description:'Accept weaker headlines in exchange for administrative capacity.',effects:{institutionalHealth:2,publicTrust:1},cost:1,risk:0},
 ]},
];

export function makeEvent(seed:number,week:number,salt:number):WorldEvent {
 const t=eventTemplates[(seed+week*7+salt*13)%eventTemplates.length];
 return {...t,id:id(seed,week*100+salt),week,resolved:false,choices:t.choices.map(c=>({...c,effects:{...c.effects}}))};
}

export function makeBill(area:Issue, seed:number, week:number):Bill {
 const effects:Bill['effects']={};
 if(area.id==='economy'){effects.growth=2;effects.unemployment=-1;effects.deficit=area.cost/4;}
 if(area.id==='health'){effects.healthcare=4;effects.approval=1;effects.deficit=area.cost/3;}
 if(area.id==='climate'){effects.climate=4;effects.growth=1;effects.deficit=area.cost/3;}
 if(area.id==='immigration'){effects.borderPressure=-4;effects.stability=1;effects.approval=1;}
 if(area.id==='education'){effects.education=4;effects.growth=1;effects.deficit=area.cost/3;}
 if(area.id==='infrastructure'){effects.economy=2;effects.growth=2;effects.deficit=area.cost/3;}
 if(area.id==='justice'){effects.publicTrust=2;effects.stability=1;}
 if(area.id==='defense'){effects.readiness=4;effects.globalStanding=1;effects.deficit=area.cost/3;}
 if(area.id==='housing'){effects.approval=2;effects.economy=1;effects.deficit=area.cost/3;}
 if(area.id==='technology'){effects.growth=2;effects.education=1;effects.deficit=area.cost/4;}
 return {id:id(seed,week*31+area.id.length),title:`${area.name} Modernization Act`,area:area.id,cost:area.cost,support:Math.round(area.support*.65+area.urgency*.15),opposition:Math.round(area.partisan*.55+20),stage:'draft',weeksInCongress:0,effects,description:`A targeted federal package addressing ${area.name.toLowerCase()} through a mix of implementation funding, oversight, and agency coordination.`};
}

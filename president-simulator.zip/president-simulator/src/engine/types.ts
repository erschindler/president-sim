export type PolicyArea = 'economy'|'health'|'climate'|'immigration'|'education'|'infrastructure'|'justice'|'defense'|'housing'|'technology';
export type EventKind = 'crisis'|'legislation'|'diplomacy'|'economy'|'media'|'personnel'|'opportunity'|'campaign';
export type View = 'overview'|'domestic'|'congress'|'cabinet'|'diplomacy'|'intelligence'|'media'|'campaign'|'history';
export interface Metrics {
  approval:number; economy:number; inflation:number; unemployment:number; deficit:number; debt:number; growth:number;
  unity:number; stability:number; globalStanding:number; readiness:number; climate:number; healthcare:number; education:number;
  borderPressure:number; publicTrust:number; corruption:number; institutionalHealth:number;
}
export interface Issue { id:PolicyArea; name:string; support:number; urgency:number; status:string; description:string; cost:number; partisan:number; }
export interface Person { id:string; name:string; role:string; faction:string; loyalty:number; competence:number; ambition:number; trust:number; publicProfile:string; privateAgenda:string; stress:number; }
export interface Bill { id:string; title:string; area:PolicyArea; cost:number; support:number; opposition:number; stage:'draft'|'committee'|'floor'|'passed'|'failed'; weeksInCongress:number; effects:Partial<Metrics>; description:string; }
export interface WorldEvent { id:string; week:number; kind:EventKind; title:string; body:string; severity:number; choices:Choice[]; resolved:boolean; chosen?:string; effects?:Partial<Metrics>; tags:string[]; }
export interface Choice { id:string; label:string; description:string; effects:Partial<Metrics>; cost?:number; risk?:number; requirement?:string; hiddenRisk?:number; }
export interface ForeignState { id:string; name:string; leader:string; relation:number; tension:number; trade:number; military:number; reliability:number; issue:string; }
export interface NewsItem { id:string; week:number; outlet:string; headline:string; tone:'positive'|'negative'|'mixed'; text:string; topic:string; reach:number; }
export interface HistoryEntry { week:number; date:string; title:string; detail:string; impact:string; }
export interface GameState {
  schemaVersion:number; seed:number; difficulty:'story'|'standard'|'hard'; presidentName:string; party:'Progressive Coalition'|'National Union'; term:number; week:number; date:string; daysRemaining:number;
  metrics:Metrics; budget:number; politicalCapital:number; executiveOrders:number; executiveOrderLimit:number; emergencyDeclarations:number;
  issues:Issue[]; cabinet:Person[]; congress:{senateSeats:number; houseSeats:number; senateNeeded:number; houseNeeded:number; partyDiscipline:number; publicMandate:number; bills:Bill[]; relations:number};
  foreign:ForeignState[]; events:WorldEvent[]; news:NewsItem[]; history:HistoryEntry[]; selectedView:View; campaign:{funds:number; groundGame:number; message:string; oppositionStrength:number; electionIn:number; momentum:number};
  flags:Record<string,number|boolean|string>; lastTurnSummary:string[]; gameOver?:{title:string;body:string};
}

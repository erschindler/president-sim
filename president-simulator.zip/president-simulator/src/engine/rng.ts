export function rand(seed:number, salt:number=0):number {
  let x = (seed ^ Math.imul(salt + 0x9e3779b9, 0x85ebca6b)) | 0;
  x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
  return ((x >>> 0) % 1_000_000) / 1_000_000;
}
export function clamp(n:number,min=0,max=100){ return Math.max(min,Math.min(max,n)); }
export function signed(n:number){ return `${n>0?'+':''}${Math.round(n)}`; }
export function id(seed:number, salt:number){ return `${seed.toString(36)}-${salt.toString(36)}`; }

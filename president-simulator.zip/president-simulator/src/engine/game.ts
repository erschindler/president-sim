import type { Bill, Choice, GameState, HistoryEntry, Issue, Metrics, Person, PolicyArea, WorldEvent } from './types';
import { clamp, id, rand } from './rng';
import { baseCabinet, baseForeign, baseIssues, makeBill, makeEvent, openingEvent } from './scenarios';

const initialMetrics:Metrics={approval:54,economy:57,inflation:62,unemployment:42,deficit:48,debt:54,growth:52,unity:49,stability:68,globalStanding:61,readiness:70,climate:43,healthcare:51,education:56,borderPressure:61,publicTrust:53,corruption:18,institutionalHealth:66};
const metricNames:Record<keyof Metrics,string>={approval:'Approval',economy:'Economic confidence',inflation:'Inflation pressure',unemployment:'Unemployment pressure',deficit:'Deficit pressure',debt:'Debt pressure',growth:'Growth outlook',unity:'National unity',stability:'Stability',globalStanding:'Global standing',readiness:'Defense readiness',climate:'Climate resilience',healthcare:'Healthcare access',education:'Education outcomes',borderPressure:'Border pressure',publicTrust:'Public trust',corruption:'Corruption risk',institutionalHealth:'Institutional health'};
const lowerIsBetter=new Set<keyof Metrics>(['inflation','unemployment','deficit','debt','borderPressure','corruption']);
const capMetric=(key:keyof Metrics,n:number)=> key==='deficit'||key==='debt'?clamp(n,0,100):clamp(n,0,100);

export function createGame(options?:{seed?:number;name?:string;party?:GameState['party'];difficulty?:GameState['difficulty']}):GameState {
 const seed=options?.seed ?? Math.floor(Math.random()*2_000_000_000);
 return {schemaVersion:1,seed,difficulty:options?.difficulty??'standard',presidentName:options?.name||'President Alex Morgan',party:options?.party??'Progressive Coalition',term:1,week:1,date:'January 20, Year 1',daysRemaining:1460,
 metrics:{...initialMetrics},budget:62,politicalCapital:50,executiveOrders:0,executiveOrderLimit:12,emergencyDeclarations:0,issues:baseIssues.map(x=>({...x})),cabinet:baseCabinet.map(x=>({...x})),congress:{senateSeats:50,houseSeats:218,senateNeeded:60,houseNeeded:218,partyDiscipline:68,publicMandate:54,bills:[],relations:50},foreign:baseForeign.map(x=>({...x})),events:[{...openingEvent,choices:openingEvent.choices.map(c=>({...c,effects:{...c.effects}}))}],news:[],history:[{week:1,date:'January 20, Year 1',title:'Inauguration Day',detail:'A new administration takes office with a narrow governing window and a divided political environment.',impact:'Starting conditions'}],selectedView:'overview',campaign:{funds:30,groundGame:42,message:'Competence, stability, and measurable progress',oppositionStrength:48,electionIn:1300,momentum:0},flags:{firstWeekResolved:false},lastTurnSummary:['The administration has taken office. Your first decisions will set expectations.']};
}

export function metricDelta(state:GameState,effects:Partial<Metrics>):string[] {
 const changes:string[]=[];
 for(const [raw,value] of Object.entries(effects)){
  const key=raw as keyof Metrics; if(typeof value!=='number') continue;
  const before=state.metrics[key]; const after=capMetric(key,before+value); state.metrics[key]=after;
  if(Math.abs(after-before)>=0.5){const favorable=lowerIsBetter.has(key)?after<before:after>before; changes.push(`${metricNames[key]} ${after>before?'+':''}${Math.round(after-before)} (${favorable?'favorable':'unfavorable'})`);}
 }
 return changes;
}
function pushHistory(state:GameState,title:string,detail:string,impact:string){
 state.history.unshift({week:state.week,date:state.date,title,detail,impact}); if(state.history.length>160) state.history.length=160;
}
function pushNews(state:GameState,outlet:string,headline:string,tone:'positive'|'negative'|'mixed',text:string,topic:string,reach:number){
 state.news.unshift({id:id(state.seed,state.week*997+state.news.length+3),week:state.week,outlet,headline,tone,text,topic,reach});if(state.news.length>80)state.news.length=80;
}
function addEvent(state:GameState,event:WorldEvent){ if(state.events.filter(e=>!e.resolved).length<5)state.events.unshift(event); }
function hasTagEvent(state:GameState,tag:string){return state.events.some(e=>!e.resolved&&e.tags.includes(tag));}

export function resolveEvent(state:GameState,eventId:string,choiceId:string):GameState {
 const event=state.events.find(e=>e.id===eventId); if(!event||event.resolved)return state;
 const choice=event.choices.find(c=>c.id===choiceId); if(!choice)return state;
 if((choice.cost??0)>state.budget){state.lastTurnSummary=['Insufficient discretionary capacity for that response. Choose a lower-cost option or wait for the next budget update.'];return state;}
 state.budget=clamp(state.budget-(choice.cost??0),0,100);
 const changes=metricDelta(state,choice.effects);
 const risk=(choice.risk??0)+(state.difficulty==='hard'?1:0);
 if(risk>0 && rand(state.seed,state.week*71+choice.id.length) < risk*.09){
  const setback:Partial<Metrics>={publicTrust:-1,stability:-1};
  if(choice.hiddenRisk) setback.corruption=(choice.hiddenRisk);
  const riskChanges=metricDelta(state,setback); changes.push(...riskChanges);
  pushNews(state,'Capitol Ledger',`${event.title}: implementation complications emerge`,'negative','Officials say the chosen response has encountered coordination, legal, or political friction. The full consequences are not yet clear.','governance',52);
 }
 event.resolved=true;event.chosen=choiceId;event.effects={...choice.effects};
 state.politicalCapital=clamp(state.politicalCapital-(choice.cost??0)*1.5+((choice.risk??0)===0?1:0),0,100);
 const detail=`${choice.label}. ${choice.description}`;
 pushHistory(state,`${event.title} — ${choice.label}`,detail,changes.slice(0,4).join('; ')||'No immediate measurable change');
 pushNews(state,'National Desk',`${event.title}: White House chooses ${choice.label.toLowerCase()}`,changes.some(c=>c.includes('unfavorable'))?'mixed':'positive',detail,event.tags[0]||'politics',60+event.severity*6);
 state.lastTurnSummary=[`${event.title} resolved.`,...changes.slice(0,5),`Discretionary capacity: ${Math.round(state.budget)}.`];
 if(event.id==='opening-brief')state.flags.firstWeekResolved=true;
 return checkGameOver(state);
}

export function proposeBill(state:GameState,areaId:PolicyArea):GameState {
 const area=state.issues.find(i=>i.id===areaId); if(!area)return state;
 if(state.congress.bills.some(b=>b.area===areaId&&b.stage!=='failed')){state.lastTurnSummary=[`A ${area.name} bill is already active.`];return state;}
 if(state.politicalCapital<5){state.lastTurnSummary=['Political capital is too low to launch a new legislative push. Build support or resolve an active issue first.'];return state;}
 const bill=makeBill(area,state.seed+state.week,state.week);state.congress.bills.unshift(bill);state.politicalCapital=clamp(state.politicalCapital-5,0,100);
 pushHistory(state,'Legislation introduced',`${bill.title} entered the legislative process. Its prospects depend on coalition-building, public support, and committee negotiations.`,'Political capital -5');
 state.lastTurnSummary=[`${bill.title} introduced.`,`Initial support estimate: ${bill.support}%.`,`The bill will move through committee and floor stages as weeks pass.`];return state;
}

export function takeExecutiveAction(state:GameState,action:'order'|'address'|'negotiate'|'oversight'|'deployment'):GameState {
 if(action==='order'){
  if(state.executiveOrders>=state.executiveOrderLimit){state.lastTurnSummary=['You have reached the current executive-order planning limit. Further action may require congressional authority or a revised legal basis.'];return state;}
  if(state.politicalCapital<7){state.lastTurnSummary=['Insufficient political capital to support a defensible executive action.'];return state;}
  state.executiveOrders++;state.politicalCapital=clamp(state.politicalCapital-7,0,100);
  const c=metricDelta(state,{stability:1,institutionalHealth:-1,approval:1,publicTrust:-1});
  pushHistory(state,'Executive order signed','A narrowly scoped directive was issued to coordinate an existing agency priority. Implementation will depend on legal authority and agency capacity.',c.join('; '));
  state.lastTurnSummary=['Executive order signed. It creates a short-term signal of action but carries implementation and legal scrutiny.'];
 }
 if(action==='address'){
  state.politicalCapital=clamp(state.politicalCapital-3,0,100);
  const effects:Partial<Metrics>={approval:2,publicTrust:1,unity:1};
  if(state.metrics.publicTrust<40){effects.approval=-1;effects.publicTrust=-1;}
  const c=metricDelta(state,effects);pushNews(state,'National Broadcast','President delivers an address on the administration’s priorities','mixed','The speech lays out goals, but the next test will be whether the administration can translate them into measurable outcomes.','communications',75);
  pushHistory(state,'National address delivered','The President made a direct case for the administration’s priorities.',c.join('; '));state.lastTurnSummary=['Address delivered. Communication can focus attention, but repeated speeches without delivery will lose value.'];
 }
 if(action==='negotiate'){
  if(state.politicalCapital<4){state.lastTurnSummary=['Insufficient political capital to support a major congressional negotiation.'];return state;}
  state.politicalCapital=clamp(state.politicalCapital-4,0,100);state.congress.relations=clamp(state.congress.relations+5,0,100);state.congress.partyDiscipline=clamp(state.congress.partyDiscipline-1,0,100);
  const c=metricDelta(state,{unity:2,stability:2,approval:1});pushHistory(state,'Congressional negotiations','The legislative affairs team opened a cross-party negotiation and offered procedural concessions.',c.join('; '));state.lastTurnSummary=['Negotiations improved working relations with Congress. Compromise may increase passage odds but can frustrate parts of your own coalition.'];
 }
 if(action==='oversight'){
  if(state.budget<2){state.lastTurnSummary=['Insufficient discretionary capacity for an oversight review.'];return state;}
  state.budget-=2;const c=metricDelta(state,{publicTrust:2,corruption:-2,institutionalHealth:2,approval:-1});pushHistory(state,'Independent oversight review launched','The administration requested an accelerated review of procurement and implementation controls.',c.join('; '));state.lastTurnSummary=['Oversight review launched. It costs time and political attention but can improve institutional credibility.'];
 }
 if(action==='deployment'){
  if(state.budget<4){state.lastTurnSummary=['Insufficient discretionary capacity for a readiness deployment.'];return state;}
  state.budget-=4;const c=metricDelta(state,{readiness:3,globalStanding:1,deficit:1});pushHistory(state,'Readiness posture adjusted','A limited deployment and readiness package was approved after interagency review.',c.join('; '));state.lastTurnSummary=['Readiness increased. Costs and diplomatic signals will be assessed in the next turn.'];
 }
 return checkGameOver(state);
}

export function advanceWeek(previous:GameState):GameState {
 if(previous.gameOver)return previous;
 const state=structuredClone(previous);state.week++;state.daysRemaining=Math.max(0,state.daysRemaining-7);state.campaign.electionIn=Math.max(0,state.campaign.electionIn-7);
 const year=Math.floor((state.week-1)/52)+1;const weekOfYear=((state.week-1)%52)+1;state.date=`Week ${weekOfYear}, Year ${year}`;
 const summary:string[]=[];
 // Macroeconomic drift: metrics are pressures or conditions, not a single morality score.
 const econDrift=(state.metrics.growth-50)*.025;
 state.metrics.inflation=clamp(state.metrics.inflation+(state.metrics.deficit>70?.35:-.15)+(state.metrics.economy>65?-.2:0)+rand(state.seed,state.week*3)*.5-0.2);
 state.metrics.unemployment=clamp(state.metrics.unemployment+(state.metrics.growth<45?.35:-.15)+rand(state.seed,state.week*5)*.45-.2);
 state.metrics.growth=clamp(state.metrics.growth+econDrift+(state.metrics.inflation>70?-.3:0)+rand(state.seed,state.week*7)*.5-.22);
 state.metrics.economy=clamp(state.metrics.economy+(state.metrics.growth-50)*.045-(state.metrics.inflation-50)*.02+rand(state.seed,state.week*11)*.5-.25);
 state.metrics.deficit=clamp(state.metrics.deficit+(state.budget<30?1:.15)+(state.metrics.growth>60?-.2:0));
 state.metrics.debt=clamp(state.metrics.debt+.22+(state.metrics.deficit-50)*.012);
 // Public confidence responds to both policy outcomes and institutional competence.
 const approvalDelta=(state.metrics.economy-50)*.025-(state.metrics.inflation-50)*.018-(state.metrics.unemployment-40)*.014+(state.metrics.stability-60)*.012+(state.metrics.publicTrust-50)*.018;
 state.metrics.approval=clamp(state.metrics.approval+approvalDelta+(rand(state.seed,state.week*17)-.5)*1.6);
 state.metrics.publicTrust=clamp(state.metrics.publicTrust+(state.metrics.institutionalHealth-60)*.018-(state.metrics.corruption-20)*.025+(rand(state.seed,state.week*19)-.5)*.6);
 state.metrics.unity=clamp(state.metrics.unity+(state.congress.relations-50)*.012+(state.metrics.stability-60)*.008-(state.metrics.approval<35?.15:0));
 state.metrics.stability=clamp(state.metrics.stability+(state.metrics.unity-50)*.018-(state.metrics.corruption-20)*.02+(rand(state.seed,state.week*23)-.5)*.4);
 state.metrics.institutionalHealth=clamp(state.metrics.institutionalHealth+(state.metrics.publicTrust-50)*.012-(state.metrics.corruption-20)*.02);
 state.metrics.globalStanding=clamp(state.metrics.globalStanding+(state.foreign.reduce((s,f)=>s+f.relation,0)/state.foreign.length-50)*.018);
 state.metrics.borderPressure=clamp(state.metrics.borderPressure+(hasTagEvent(state,'immigration')?1:0)+(rand(state.seed,state.week*29)-.55)*.5);
 state.metrics.readiness=clamp(state.metrics.readiness-.1+(state.budget>65?.1:0));
 state.budget=clamp(state.budget+1.2-(state.metrics.deficit>70?.7:0),0,100);
 state.politicalCapital=clamp(state.politicalCapital+(state.metrics.approval-50)*.035+(state.congress.relations-50)*.025-.4,0,100);
 // Cabinet stress and loyalty evolve from workload and perceived success.
 state.cabinet=state.cabinet.map((p,i)=>({...p,stress:clamp(p.stress+(state.metrics.stability<45?2:0)+(state.metrics.approval<35?1:0)-.8+rand(state.seed,state.week*31+i)*1.2),loyalty:clamp(p.loyalty+(state.metrics.approval>58?.2:-.15)+(p.stress>75?-1:0))}));
 // Foreign relations move independently; high tension creates risk, but not guaranteed war.
 state.foreign=state.foreign.map((f,i)=>{const t=rand(state.seed,state.week*43+i);const tension=clamp(f.tension+(t>.91?2:t<.1?-2:0)+(f.relation<35?.15:0));return {...f,tension,relation:clamp(f.relation+(state.metrics.globalStanding-50)*.012+(t>.82?1:t<.13?-1:0)),reliability:clamp(f.reliability+(f.relation>65?.1:-.1))};});
 // Legislation advances gradually; passing is not guaranteed and costs coalition capital.
 for(const bill of state.congress.bills){
  if(bill.stage==='passed'||bill.stage==='failed')continue;bill.weeksInCongress++;
  if(bill.stage==='draft')bill.stage='committee';
  else if(bill.stage==='committee'&&bill.weeksInCongress>=2){const chance=clamp((bill.support-state.metrics.approval*.1+state.congress.relations*.18+state.congress.partyDiscipline*.12-state.metrics.unity*.08)/100,.12,.86);if(rand(state.seed,state.week+bill.id.length)<chance){bill.stage='floor';}else if(bill.weeksInCongress>5){bill.stage='failed';summary.push(`${bill.title} stalled in committee.`);}}
  else if(bill.stage==='floor'&&bill.weeksInCongress>=3){const chance=clamp((bill.support+state.congress.relations*.22+state.metrics.publicTrust*.08-bill.opposition*.2)/100,.08,.82);if(rand(state.seed,state.week*2+bill.id.length)<chance){bill.stage='passed';const c=metricDelta(state,bill.effects);state.budget=clamp(state.budget-bill.cost*.35,0,100);pushHistory(state,'Legislation enacted',`${bill.title} passed after ${bill.weeksInCongress} weeks. ${bill.description}`,c.join('; '));summary.push(`${bill.title} passed Congress.`);}else if(bill.weeksInCongress>6){bill.stage='failed';state.politicalCapital=clamp(state.politicalCapital-2,0,100);summary.push(`${bill.title} failed to clear the floor.`);}}
 }
 // Create a limited number of new events. Existing unresolved events remain visible.
 if(state.week===2&&!state.flags.firstWeekResolved){addEvent(state,makeEvent(state.seed,state.week,1));summary.push('The opening briefing remains unresolved.');}
 if(state.week%2===0 && state.events.filter(e=>!e.resolved).length<2){const e=makeEvent(state.seed,state.week,2);addEvent(state,e);summary.push(`New issue: ${e.title}.`);}
 if(state.week%5===0){const issue=state.issues.slice().sort((a,b)=>b.urgency-a.urgency)[0];const change=rand(state.seed,state.week*47)>.5?1:-1;issue.urgency=clamp(issue.urgency+change*2);pushNews(state,'The National Ledger',`New focus group puts ${issue.name.toLowerCase()} back in the spotlight`,'mixed',`Public attention is shifting toward ${issue.name.toLowerCase()}. The numbers are a signal, not a verdict, and may respond to the administration's next actions.`,issue.id,45);summary.push(`Public attention is shifting toward ${issue.name.toLowerCase()}.`);}
 if(state.week%7===0){const foreign=state.foreign[Math.floor(rand(state.seed,state.week*53)*state.foreign.length)];if(foreign.tension>68)addEvent(state,makeEvent(state.seed,state.week,3));}
 if(state.metrics.corruption>55){state.metrics.publicTrust=clamp(state.metrics.publicTrust-.5);state.metrics.institutionalHealth=clamp(state.metrics.institutionalHealth-.4);}
 state.lastTurnSummary=summary.length?summary:['A week has passed. No single event dominated the briefing, but the underlying indicators continue to move.'];
 pushHistory(state,'Weekly situation report',state.lastTurnSummary.join(' '),`Approval ${Math.round(state.metrics.approval)} · Economy ${Math.round(state.metrics.economy)} · Trust ${Math.round(state.metrics.publicTrust)}`);
 return checkGameOver(state);
}

export function appointOfficial(state:GameState,personId:string):GameState {
 const person=state.cabinet.find(p=>p.id===personId);if(!person)return state;
 if(person.stress<65){state.lastTurnSummary=[`${person.name} is not currently at a resignation threshold. Consider workload support or wait for new information.`];return state;}
 state.cabinet=state.cabinet.filter(p=>p.id!==personId);state.metrics.institutionalHealth=clamp(state.metrics.institutionalHealth-2);state.metrics.stability=clamp(state.metrics.stability-2);state.politicalCapital=clamp(state.politicalCapital-3);
 pushHistory(state,'Cabinet departure',`${person.name}, ${person.role}, left the administration after sustained pressure. A replacement process is required.`, 'Stability -2; institutional health -2');state.lastTurnSummary=[`${person.name} has departed. A future personnel action should fill the vacancy.`];return state;
}

export function relieveStress(state:GameState,personId:string):GameState {
 const p=state.cabinet.find(x=>x.id===personId);if(!p)return state;
 if(state.budget<1){state.lastTurnSummary=['Insufficient discretionary capacity for staff support.'];return state;}
 state.budget-=1;p.stress=clamp(p.stress-15);p.trust=clamp(p.trust+2);state.politicalCapital=clamp(state.politicalCapital-1);
 pushHistory(state,'Cabinet support provided',`The President met with ${p.name} and approved a workload reset for the ${p.role} office.`,'Cabinet stress reduced');state.lastTurnSummary=[`${p.name}'s stress fell. A healthier staff can improve execution, but attention and resources are limited.`];return state;
}

export function diplomacyAction(state:GameState,foreignId:string,action:'summit'|'trade'|'sanctions'|'aid'):GameState {
 const f=state.foreign.find(x=>x.id===foreignId);if(!f)return state;
 const cost=action==='aid'?5:action==='summit'?2:action==='trade'?3:1;
 if(state.budget<cost){state.lastTurnSummary=['Insufficient discretionary capacity for that diplomatic action.'];return state;}state.budget-=cost;
 let effects:Partial<Metrics>={};
 if(action==='summit'){f.relation=clamp(f.relation+4);f.tension=clamp(f.tension-3);effects={globalStanding:2,stability:1};}
 if(action==='trade'){f.trade=clamp(f.trade+6);f.relation=clamp(f.relation+2);effects={economy:1,growth:1,globalStanding:1,deficit:1};}
 if(action==='sanctions'){f.relation=clamp(f.relation-7);f.tension=clamp(f.tension+8);effects={globalStanding:f.reliability<55?1:-1,stability:-1,readiness:1};}
 if(action==='aid'){f.relation=clamp(f.relation+5);f.reliability=clamp(f.reliability+2);effects={globalStanding:2,publicTrust:1,deficit:2};}
 const c=metricDelta(state,effects);pushHistory(state,`Diplomatic action: ${action}`,`The administration took a ${action} initiative with ${f.name}. Effects will depend on follow-through and the other government's response.`,c.join('; '));state.lastTurnSummary=[`${action[0].toUpperCase()+action.slice(1)} initiative completed with ${f.name}.`,...c];return state;
}

export function campaignAction(state:GameState,action:'fundraise'|'organize'|'message'|'debate'):GameState {
 if(action==='fundraise'){state.campaign.funds=clamp(state.campaign.funds+8+(state.metrics.approval>50?2:0),0,100);state.campaign.momentum=clamp(state.campaign.momentum+1);state.lastTurnSummary=['Fundraising improved campaign reserves. Donor attention is useful, but it may increase pressure from organized interests.'];}
 if(action==='organize'){if(state.campaign.funds<4){state.lastTurnSummary=['Campaign funds are too low to expand field operations.'];return state;}state.campaign.funds-=4;state.campaign.groundGame=clamp(state.campaign.groundGame+5);state.campaign.momentum=clamp(state.campaign.momentum+2);state.lastTurnSummary=['Field organization improved. Ground operations can matter more than a short-lived news cycle as the election approaches.'];}
 if(action==='message'){state.campaign.message='A record of delivery, stability, and practical results';state.campaign.momentum=clamp(state.campaign.momentum+2);state.metrics.approval=clamp(state.metrics.approval+1);state.lastTurnSummary=['Campaign message refreshed around delivery. The message will only hold if governing outcomes support it.'];}
 if(action==='debate'){const strength=(state.metrics.approval-50)*.08+(state.campaign.groundGame-50)*.04+(rand(state.seed,state.week*61)-.5)*5;state.campaign.momentum=clamp(state.campaign.momentum+strength);state.metrics.approval=clamp(state.metrics.approval+strength*.3);state.lastTurnSummary=[`Debate performance shifted campaign momentum by ${strength>0?'+':''}${strength.toFixed(1)}.`];}
 pushHistory(state,'Campaign operation',state.lastTurnSummary.join(' '),`Momentum ${Math.round(state.campaign.momentum)}`);return state;
}

function checkGameOver(state:GameState):GameState {
 if(state.metrics.stability<=8){state.gameOver={title:'A Constitutional Crisis',body:'Institutional breakdown and political instability have reached a level the administration can no longer manage. Your term ends amid a crisis of legitimacy.'};}
 else if(state.metrics.publicTrust<=5){state.gameOver={title:'Government Loses Public Legitimacy',body:'Public confidence has collapsed. The administration can no longer maintain a functioning governing coalition.'};}
 else if(state.daysRemaining<=0){const score=state.metrics.approval*.25+state.metrics.publicTrust*.2+state.metrics.economy*.15+state.metrics.institutionalHealth*.15+state.metrics.globalStanding*.1+state.metrics.stability*.15;state.gameOver={title:score>=58?'A Legacy of Durable Results':score>=43?'A Mixed Presidential Legacy':'A Presidency Defined by Crisis',body:`Your first term has ended. Final legacy index: ${Math.round(score)}/100. Approval: ${Math.round(state.metrics.approval)}. Public trust: ${Math.round(state.metrics.publicTrust)}. Institutional health: ${Math.round(state.metrics.institutionalHealth)}. The result reflects the cumulative consequences of your choices, not any single decision.`};}
 return state;
}

export function describeMetric(key:keyof Metrics){return metricNames[key];}
export function metricIsGood(key:keyof Metrics){return !lowerIsBetter.has(key);}
export function activeEvents(state:GameState){return state.events.filter(e=>!e.resolved);}
export function cabinetRisk(p:Person){return clamp((p.stress-55)*.8+(100-p.loyalty)*.25+(100-p.trust)*.2);}

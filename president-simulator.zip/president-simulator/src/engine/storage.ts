import type { GameState } from './types';
const KEY='president-simulator-save-v1';
export function loadGame():GameState|null {try{const raw=localStorage.getItem(KEY);if(!raw)return null;const value=JSON.parse(raw) as GameState;if(value.schemaVersion!==1)return null;return value;}catch{return null;}}
export function saveGame(state:GameState){try{localStorage.setItem(KEY,JSON.stringify(state));return true;}catch{return false;}}
export function deleteSave(){localStorage.removeItem(KEY);}
